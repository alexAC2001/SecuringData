package beans;

public class Order {
	
	// Properties
	public String orderNumber = "";
	public String productName = "";
	public float price = 0;
	public int quantity = 0;	
	
	// Non-default constructor that initializes the properties.
	public Order(String orderNumber, String productName, float price, int quantity) 
	{
		super();
		this.orderNumber = orderNumber;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
	}
	// Getters and setters
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
