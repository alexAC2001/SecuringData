package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
//import javax.faces.view.ViewScoped;

//Annotations
@ManagedBean
//@ViewScoped
public class Orders {

	//New List of type Orders
	// Order is the object and orders is the list.
	public List <Order> orders = new ArrayList<Order>(); 
	
	// This default constructor has a predetermined set of data that
	// fills the properties from the Order class.
	public Orders()
	{
		orders.add(new Order("000", "Avengers", (float)15.00, 1));
		orders.add(new Order("001", "Captain America", (float)13.25, 1));
		orders.add(new Order("002", "Joker", (float)11.50, 3));
		orders.add(new Order("003", "Tenet", (float)14.50, 4));
		orders.add(new Order("004", "Transformers", (float)12.00, 3));
		orders.add(new Order("005", "Fast and the Furious", (float)14.75, 1));
		orders.add(new Order("006", "Avatar", (float)15.25, 1));
		orders.add(new Order("007", "Halloween", (float)11.25, 2));
		orders.add(new Order("008", "Child's Play", (float)13.50, 1));
		orders.add(new Order("009", "Toy Story", (float)11.75, 1));
		orders.add(new Order("010", "Inside Out", (float)10.00, 2));
		orders.add(new Order("011", "Twilight", (float)0.99, 1));
		orders.add(new Order("012", "Harry Potter", (float)9.50, 4));
	}
	// Getters and Setters
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}	
}
