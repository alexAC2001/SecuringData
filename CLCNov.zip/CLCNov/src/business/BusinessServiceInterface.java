package business;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
@Stateless
@Local
@Alternative
public interface BusinessServiceInterface {

	public void test();
	public List<Order> getOrder();
	public void setOrders(List<Order> orders);
	
}
