package business;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import beans.Order;
@Stateless
@Local(BusinessServiceInterface.class)
@Alternative
public class BusinessService1 implements BusinessServiceInterface {

	List<Order> orders = new ArrayList<Order>();	
	
	@Override
	public void test() {
		System.out.println("======================Hello from the test method in BusinessService1. Business Service Version #1");	
	}	
	public BusinessService1() {

	}
	@Override
	public List<Order> getOrder() {
		// TODO Auto-generated method stub
		return orders;
	}
	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;		
	}
}
